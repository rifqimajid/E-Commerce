package com.adithyarachmat.e_commerce.Admin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.adithyarachmat.e_commerce.R;

public class StaffLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_login);
    }
}