package com.adithyarachmat.e_commerce.Home.Books;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.adithyarachmat.e_commerce.R;

public class Book1Detail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book1_detail);
    }
}