package com.adithyarachmat.e_commerce.Home.OtherItems;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.adithyarachmat.e_commerce.R;

public class OtherItem1Detail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other_item1_detail);
    }
}