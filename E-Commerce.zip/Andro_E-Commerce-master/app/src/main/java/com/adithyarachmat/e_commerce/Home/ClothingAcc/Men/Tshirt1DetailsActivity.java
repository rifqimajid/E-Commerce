package com.adithyarachmat.e_commerce.Home.ClothingAcc.Men;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.adithyarachmat.e_commerce.R;

public class Tshirt1DetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tshirt1_details);
    }
}