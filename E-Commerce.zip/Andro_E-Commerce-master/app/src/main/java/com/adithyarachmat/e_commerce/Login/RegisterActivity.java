package com.adithyarachmat.e_commerce.Login;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.adithyarachmat.e_commerce.R;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }
}